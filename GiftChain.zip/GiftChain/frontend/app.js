let contract;
let accounts;

window.addEventListener('load', async () => {
  if (window.ethereum) {
    window.web3 = new Web3(ethereum);
    await ethereum.enable();
  } else {
    alert("Please install MetaMask to use this app");
    return;
  }

  const res = await fetch("GiftChain.json"); // Ensure this matches your actual path
  const data = await res.json();

  const networkId = await web3.eth.net.getId();
  const deployedNetwork = data.networks[networkId];

  contract = new web3.eth.Contract(data.abi, deployedNetwork.address);

  accounts = await web3.eth.getAccounts();

  loadDonations();
});

async function donate() {
  const donor = document.getElementById("donor").value;
  const amount = document.getElementById("amount").value;

  if (!donor || !amount) {
    alert("Please fill in both fields.");
    return;
  }

  await contract.methods.donate(donor).send({
    from: accounts[0],
    value: web3.utils.toWei(amount, "ether")
  });

  loadDonations();
}

async function loadDonations() {
  const total = await contract.methods.getTotalDonations().call();
  const list = document.getElementById("donationList");
  list.innerHTML = "";

  for (let i = 0; i < total; i++) {
    const donation = await contract.methods.donations(i).call();
    const li = document.createElement("li");
    li.textContent = `${donation.donor} donated ${web3.utils.fromWei(donation.amount, "ether")} ETH`;
    list.appendChild(li);
  }
}
