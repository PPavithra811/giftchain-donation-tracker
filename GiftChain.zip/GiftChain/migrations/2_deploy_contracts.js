const GiftChain = artifacts.require("GiftChain");

module.exports = function (deployer) {
  deployer.deploy(GiftChain);
};
